/*  JavaScript 6th Edition
    Chapter 11
    Hands-on Project 11-4

    Author: 
    Date:   

    Filename: script.js
*/

"use strict";

